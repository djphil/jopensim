<?php
/*
 * @component jOpenSim
 * @copyright Copyright (C) 2015 FoTo50 http://www.jopensim.com/
 * @license GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */
// No direct access
defined('_JEXEC') or die('Restricted access');
?>
<h1>Terminal <?php echo $this->terminal['terminalName']; ?> is anwering:</h1>
<p><?php echo $this->pingAnswer; ?></p>